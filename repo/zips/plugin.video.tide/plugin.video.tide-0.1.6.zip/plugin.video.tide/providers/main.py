from . import streams100

# list of providers
all_providers = [
    streams100
]
