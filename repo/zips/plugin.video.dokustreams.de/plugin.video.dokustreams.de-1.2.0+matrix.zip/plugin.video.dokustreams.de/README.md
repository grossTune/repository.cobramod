# plugin.video.dokustreams.de

Kodi Addon for [Dokustreams.de](http://dokustreams.de/)

Watch documentaries, reports, interviews and discussion programmes online for free.
