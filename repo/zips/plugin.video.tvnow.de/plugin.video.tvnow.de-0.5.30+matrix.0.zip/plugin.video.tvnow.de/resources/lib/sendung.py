class Sendung():
    def __init__(self, sid, title, station, tGroup, itemType):
        self.sid = sid
        self.title = title
        self.station = station
        self.tGroup = tGroup
        self.itemType = itemType