# kodi.plugin.ytchannels

Originally by natko (https://github.com/natko1412/repo.natko1412) however it seems abandoned, so I've taken it over for now.

Forum Release Thread: https://forum.kodi.tv/showthread.php?tid=45246


To generate an API Key, follow this guide and then enter it in the Addon settings:
https://github.com/jdf76/plugin.video.youtube/wiki/Personal-API-Keys
