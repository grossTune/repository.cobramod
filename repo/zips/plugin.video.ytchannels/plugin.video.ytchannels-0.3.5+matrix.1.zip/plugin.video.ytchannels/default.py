
from resources.lib.ytchannels import ytchannels_main

ytchannels_main()
