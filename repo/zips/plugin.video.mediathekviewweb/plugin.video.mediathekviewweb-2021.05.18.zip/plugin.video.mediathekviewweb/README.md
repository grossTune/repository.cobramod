# plugin.video.mediathekviewweb

Kodi Addon for [MediathekViewWeb](https://mediathekviewweb.de/)

MediathekViewWeb is a simple browser interface for accessing the movie list of the MediathekView project.
