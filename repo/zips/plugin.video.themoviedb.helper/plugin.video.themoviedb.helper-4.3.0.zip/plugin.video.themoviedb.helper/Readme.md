# TheMovieDB Helper [![License](https://img.shields.io/badge/License-GPLv3-blue)](https://github.com/jurialmunkey/plugin.video.themoviedb.helper/blob/master/LICENSE.txt)

See [TMDbHelper Wiki](https://github.com/jurialmunkey/plugin.video.themoviedb.helper/wiki) for usage

Kodi Versions:

- [Leia](https://github.com/jurialmunkey/plugin.video.themoviedb.helper/tree/leia)
- [Matrix](https://github.com/jurialmunkey/plugin.video.themoviedb.helper/tree/matrix)
