DATA_URL = 'https://i.mjh.nz/PlutoTV/app.json.gz'
ALL = '_'
UUID_NAMESPACE = '122e1611-0232-4336-bf43-e054c8ecd0d5'