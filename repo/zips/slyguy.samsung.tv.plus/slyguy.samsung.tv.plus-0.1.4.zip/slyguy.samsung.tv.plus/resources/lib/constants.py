DATA_URL = 'https://i.mjh.nz/SamsungTVPlus/app.json.gz'
ALL = '_'
MY_CHANNELS = 'my_channels'
