import sys
from lib import weather

if (__name__ == '__main__'):
    weather.MAIN(mode=sys.argv[1])
