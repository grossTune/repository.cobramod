#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
os._exit(1)