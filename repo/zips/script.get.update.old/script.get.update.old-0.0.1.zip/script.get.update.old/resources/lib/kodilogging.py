# -*- coding: utf-8 -*-

from __future__ import unicode_literals
from resources.lib.kodiutils import get_setting_as_bool

import logging
import xbmc
import xbmcaddon


class KodiLogHandler(logging.StreamHandler):

    def __init__(self):
        pass

    def emit(self, record):
        pass

    def flush(self):
        pass


def config():
    pass
